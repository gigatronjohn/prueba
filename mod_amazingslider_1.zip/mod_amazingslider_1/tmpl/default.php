<?php

/**

 * @package Amazing Slider Joomla Module

 * @author Magic Hills Pty Ltd

 * @website http://amazingslider.com

 * @copyright 2013 Magic Hills Pty Ltd All Rights Reserved

 **/

//don't allow other scripts to grab and execute our file

defined('_JEXEC') or die('Direct Access to this location is not allowed.');
?>



    
    <!-- Insert to your webpage where you want to display the slider -->
    <div class="amazingslider-wrapper" id="amazingslider-wrapper-1" style="display:block;position:relative;max-width:900px;margin:0px auto 86px;">
        <div class="amazingslider" id="amazingslider-1" style="display:block;position:relative;margin:0 auto;">
            <ul class="amazingslider-slides" style="display:none;">
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/contactenos2.jpg" alt="contactenos2"  title="contactenos2" />
                </li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/GALERIA1.jpg" alt="GALERIA1"  title="GALERIA1" />
                </li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/GALERIA2.jpg" alt="GALERIA2"  title="GALERIA2" />
                </li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/GALERIA3.jpg" alt="GALERIA3"  title="GALERIA3" />
                </li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/GALERIA4.jpg" alt="GALERIA4"  title="GALERIA4" />
                </li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/LOGO.jpeg" alt="LOGO"  title="LOGO" />
                </li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/PLATOS1.jpg" alt="PLATOS1"  title="PLATOS1" />
                </li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/PLATOS2.jpg" alt="PLATOS2"  title="PLATOS2" />
                </li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/QUIENES.png" alt="QUIENES"  title="QUIENES" />
                </li>
            </ul>
            <ul class="amazingslider-thumbnails" style="display:none;">
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/thumbnails/contactenos2-tn.jpg" alt="contactenos2" title="contactenos2" /></li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/thumbnails/GALERIA1-tn.jpg" alt="GALERIA1" title="GALERIA1" /></li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/thumbnails/GALERIA2-tn.jpg" alt="GALERIA2" title="GALERIA2" /></li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/thumbnails/GALERIA3-tn.jpg" alt="GALERIA3" title="GALERIA3" /></li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/thumbnails/GALERIA4-tn.jpg" alt="GALERIA4" title="GALERIA4" /></li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/thumbnails/LOGO-tn.jpeg" alt="LOGO" title="LOGO" /></li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/thumbnails/PLATOS1-tn.jpg" alt="PLATOS1" title="PLATOS1" /></li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/thumbnails/PLATOS2-tn.jpg" alt="PLATOS2" title="PLATOS2" /></li>
                <li><img src="<?php echo JURI::base(); ?>modules/mod_amazingslider_1/tmpl/images/thumbnails/QUIENES-tn.png" alt="QUIENES" title="QUIENES" /></li>
            </ul>
        </div>
    </div>
    <!-- End of body section HTML codes -->
    
