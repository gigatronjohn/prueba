<?php

/**

 * @package Amazing Slider Joomla Module

 * @author Magic Hills Pty Ltd

 * @website http://amazingslider.com

 * @copyright 2014 Magic Hills Pty Ltd All Rights Reserved

 **/

//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

$document = JFactory::getDocument();

if ( !empty($module->name) )
	$moduleName = $module->name;
else
	$moduleName = "amazingslider_1";

if (version_compare(JVERSION, '3.0', 'ge')) 
{
   JHtml::_('jquery.framework');
}
else 
{
	if ( !$params->get('is_second') )
		$document->addScript( JURI::base() . 'modules/mod_' . $moduleName . '/tmpl/sliderengine/jquery.js' );
}

if ( !$params->get('is_second') )
{	
	$document->addScriptDeclaration( "var joomlaBaseUrl = '" . JURI::base() . "'; " );
	$document->addScript( JURI::base() . 'modules/mod_' . $moduleName . '/tmpl/sliderengine/amazingslider.js' );
}

$document->addStyleSheet( JURI::base() . 'modules/mod_' . $moduleName . '/tmpl/sliderengine/amazingslider-1.css' );
$document->addScript( JURI::base() . 'modules/mod_' . $moduleName . '/tmpl/sliderengine/initslider-1.js' );

require(JModuleHelper::getLayoutPath( 'mod_'.$moduleName ));